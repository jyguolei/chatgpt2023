import type { APIRoute } from 'astro'
import { generatePayload, parseOpenAIStream } from '@/utils/openAI'
import { verifySignature } from '@/utils/auth'
import { fetch, ProxyAgent } from 'undici'

const apiKey = import.meta.env.OPENAI_API_KEY
const https_proxy = import.meta.env.HTTPS_PROXY

export const post: APIRoute = async (context) => {
  const body = await context.request.json()
  const { sign, time, messages } = body

  const headers = context.request.headers;
  const origin = headers.get('origin');
  const Authorization = headers.get('Authorization');
  if (!messages) {
    return new Response('No input text')
  }
  // if (import.meta.env.PROD && !await verifySignature({ t: time, m: messages?.[messages.length - 1]?.content || '', }, sign)) {
  //   return new Response('无效签名')
  // }
  const initOptions = generatePayload(apiKey, messages)
  if (https_proxy) {
    initOptions['dispatcher'] = new ProxyAgent(https_proxy)
  }
  if(Authorization == null){
    return new Response("非法请求");
  }
  const response = await fetch('https://api.openai.com/v1/chat/completions', initOptions) as Response;
  return new Response(parseOpenAIStream(response));
  // 关闭掉入口
  //return new Response("我们非常抱歉地通知您，由于某些不可抗拒的原因，本站点暂时无法使用。我们深表歉意并正在全力以赴解决问题。我们将密切关注情况，并在尽可能短的时间内恢复本站的访问功能。感谢您的耐心等待和谅解。如有任何进一步的问题或疑虑，请不要犹豫，随时与我们联系。");
}
